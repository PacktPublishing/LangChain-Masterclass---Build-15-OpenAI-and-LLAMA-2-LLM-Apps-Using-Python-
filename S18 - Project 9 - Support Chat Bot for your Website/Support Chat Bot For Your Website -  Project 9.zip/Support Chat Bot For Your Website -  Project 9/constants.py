WEBSITE_URL="https://jobs.excelcult.com/wp-sitemap-posts-post-1.xml"
PINECONE_ENVIRONMENT="gcp-starter"
PINECONE_INDEX="chatbot"